// #define PRECALCULATED_GAUSS 1


inline void atomicAdd_g_f(volatile __global float *addr, float val)
{
   union{
      unsigned int u32;
      float        f32;
   } next, expected, current;
   current.f32    = *addr;
   do{
      expected.f32 = current.f32;
      next.f32     = expected.f32 + val;
      current.u32  = atomic_cmpxchg( (volatile __global unsigned int *)addr,
                                     expected.u32, next.u32);
   } while( current.u32 != expected.u32 );
}


__kernel void Clear(__global float2 *ARES) {  // [CELLS*NRAY] SIJ, ESC
   // Clear the ARES array before simulation of the current transition
   int id = get_global_id(0) ;  // id = ray index
   if (id>=NRAY) return ;
   for(int i=0; i<CELLS; i++) {
      ARES[id*CELLS+i].x = 0.0f ;      ARES[id*CELLS+i].y = 0.0f ;
   }
}


__kernel void Sum(__global float2 *ARES, __global float2 *RES, __global float *VOLUME) {
   // Each work item has updated entries in ARES[id*CELLS+INDEX], sum these to RES[CELLS]
   int  id = get_global_id(0) ;  // id = cell index
   if (id>=CELLS) return ;
   float sij=0.0f, esc=0.0f ;
   for(int i=0; i<NRAY; i++) {
      sij += ARES[i*CELLS+id].x ;    
      esc += ARES[i*CELLS+id].y ;
   }
   // 2020-06-02 --- lets keep division with volume here... for the octree version it will be in solver !!
   RES[id].x = sij  / VOLUME[id] ;    
   RES[id].y = esc  / VOLUME[id] ;
}



__kernel void Update(
                     __global float4 *CLOUD,   //  0 [CELLS]: Vrad, Rc, dummy, sigma
                     constant float  *GAU,     //  1 precalculated gaussian profiles [GNO*CHANNELS]
                     const float      Aul,     //  2 Einstein A(upper->lower)
                     const float      A_b,     //  3 (g_u/g_l)*B(upper->lower)
                     const float      GN,      //  4 Gauss norm. == C_LIGHT/(1e5*DV*freq) * GL
                     __global float  *DIRWEI,  //  5 individual weights for the rays
                     __global float  *VOLUME,  //  6 cell volume / cloud volume
                     __global float  *STEP,    //  7 average path length [NRAY*CELLS] (GL)
                     constant float  *APL,     //  8 average path length [CELLS] (GL)
                     const float      BG,      //  9 background value (photons per ray)
                     __global float  *IP,      // 10 impact parameter [NRAY] [GL]
                     __global float2 *NI,      // 11 [CELLS]:  NI[upper] + NB_NB
                     __global float2 *ARES     // 12 [CELLS*NRAY]:  SIJ, ESC
#if (COOLING>0)
# if (DOUBLE_COOL>0)
                     ,__global double *COOL     // 13 [GLOBAL*CELLS] = cooling
# else
                     ,__global float *COOL     // 13 [CELLS] = cooling
# endif
#endif
                    )  {
   // Follow one ray, update SIJ and ESC counters
   // One work item per ray => each work item must update a separate element of ARES
   float weight, dx, doppler, tmp_tau, tmp_emit, nb_nb, factor, escape, absorbed ;
   float sum_delta_true, all_escaped, nu ;
   constant float* profile ;
   int   row, shift, INDEX ;
   int   id  = get_global_id(0) ;  // ray index
   int   lid = get_local_id(0) ;   // index within the local work group
   if  (id>=NRAY) return ;   
   float ip = IP[id] ;             // impact parameter [GL]
   
   __local float  NTRUES[LOCAL*CHANNELS] ;         // 32 * 200 channels = 25kB
   __local float *NTRUE = &NTRUES[lid*CHANNELS] ;  // spectrum in the current ray
   for(int i=0; i<CHANNELS; i++) NTRUE[i] = BG * DIRWEI[id]  ;
   
   INDEX = CELLS-1 ;    // always starts with the outermost shell
   
#if (COOLING>0)
# if (DOUBLE_COOL>0)
   double cool           = BG*DIRWEI[id]*CHANNELS ;
   COOL[CELLS*id+INDEX] -= cool ;
# else
   float cool            = BG*DIRWEI[id]*CHANNELS ;
   atomicAdd_g_f(&(COOL[INDEX]), -cool) ; // heating of the entered cell
# endif
#endif
   
   int dstep = -1 ;     // we first go inwards (dstep<0), then outwards until ray exits
   while(1) {
      dx        =  STEP[id*CELLS+INDEX] ;  // [GL]
      nu        =  NI[INDEX].x ;
      nb_nb     =  NI[INDEX].y ;
      // emitted photons divided between all passing rays ~ path length
      weight    =  DIRWEI[id]*(dx/APL[INDEX])*VOLUME[INDEX] ;  // VOLUME == fraction of cloud volume
      // CLOUD.x == radial velocity, CLOUD.y == effective radius
      doppler   =  dstep*CLOUD[INDEX].x * sqrt( max(0.0f, 1.0f-pow(ip/CLOUD[INDEX].y, 2.0f)) ) ;
      if (fabs(nb_nb)<1.0e-30f) nb_nb=1.0e-30f ; 
      tmp_tau   =  dx*nb_nb*GN ;  // GN includes GL [cm]
      tmp_emit  =  weight * nu*Aul / tmp_tau ;
      shift     =  round(doppler/WIDTH) ;
      row       =  clamp((int)round(log(CLOUD[INDEX].w/SIGMA0)/log(SIGMAX)), 0, GNO-1) ;
      profile   =  &GAU[row*CHANNELS] ;
      sum_delta_true = all_escaped = 0.0f ;
      for(int ii=max(0, shift); ii<min(CHANNELS, CHANNELS+shift); ii++)  {
#if 1
         factor           =  1.0f-exp(-tmp_tau*profile[ii-shift]) ;
#else
         factor = (fabs(tmp_tau*profile[ii-shift])>0.001f) ?  (1.0f-exp(-tmp_tau*profile[ii-shift])) : (tmp_tau*profile[ii-shift]) ;
#endif
         escape           =  tmp_emit*factor ;    // emitted photons that escape current cell
         absorbed         =  NTRUE[ii]*factor ;   // incoming photons that are absorbed
         NTRUE[ii]       +=  escape-absorbed ;
         sum_delta_true  +=  absorbed  ;          // ignore photons absorbed in emitting cell
         all_escaped     +=  escape ;             // sum of escaping photons over the profile
      }  // loop over channels
      
      // Update SIJ and ESC (note - there may be two updates, one incoming, one outgoing ray)
      ARES[id*CELLS+INDEX].x  += A_b * sum_delta_true / nb_nb  ; // to be divided by VOLUME
      // Emission ~ path length dx but also weighted according to direction, works because <WEI>==1.0
      ARES[id*CELLS+INDEX].y  += all_escaped ;                   // to be divided by VOLUME
      // barrier(CLK_LOCAL_MEM_FENCE) ;
      
#if (COOLING>0)   // total number of photons in the package as it exits the cell
# if (DOUBLE_COOL>0)
      cool = 0.0 ;
      for(int ii=0; ii<CHANNELS; ii++) cool += NTRUE[ii] ;
      COOL[id*CELLS+INDEX] += cool ;
# else
      cool = 0.0f ;
      for(int ii=0; ii<CHANNELS; ii++) cool += NTRUE[ii] ;
      atomicAdd_g_f(&(COOL[INDEX]), cool) ; // cooling of cell INDEX
# endif
#endif
      
      // 1 -> 0 is normal step
      // 1 -> 0 -> 1  is also possible, one step through a cell
      INDEX += dstep ;
      if (INDEX>=CELLS) break ;      
      if (INDEX<0) {             // we went through the centre cell, turn outwards -- NEVER ??
         INDEX = 1 ;  dstep = 1 ;
      } else {
         if (STEP[id*CELLS+INDEX]<=0.0f) { // ray does not go that far in, turn outwards
            INDEX += 2 ;  dstep  = 1 ;            
         }
      }
      if (INDEX>=CELLS) break ;
      
#if (COOLING>0)
# if (DOUBLE_COOL>0)
      if (id==10) printf("COOL[%2d] = %14.6e  - %14.6e  = %14.6e\n", INDEX, COOL[INDEX], cool, COOL[INDEX]-cool) ;
      COOL[id*CELLS+INDEX] -= cool ;      
# else
      atomicAdd_g_f(&(COOL[INDEX]), -cool) ; // heating of the next cell
# endif
#endif
      
   } // while(1)
}




__kernel void Spectra(
                      __global float4 *CLOUD,         //  0 [CELLS]: Vrad, Rc, ABUNDANCE, sigma
                      constant float  *GAU,           //  1 precalculated gaussian profiles
                      const float      GN,            //  2 Gauss normalisation == C_LIGHT/(1e5*DV*freq)
                      __global float2 *NI,            //  3 [CELLS]:  NI[upper] + NB_NB
                      const float      BG,            //  4 background intensity
                      const float      emis0,         //  5 h/(4pi)*freq*Aul*int2temp
                      __global float  *IP,            //  6 impact parameter [GL]
                      __global float  *STEP,          //  7 STEP[iray*CELLS+iray]  [GL]
                      __global float  *NTRUE_ARRAY,   //  8 NRAY*CHANNELS
                      __global float  *SUM_TAU_ARRAY, //  9 NRAY*CHANNELS
                      __global float  *RHO,           // 10 [CELLS] ... for column density calculation
                      __global float3 *COLDEN         // 11 [NRAY] = N, N_mol, tau
                     )
{
   // one work item per ray; the same rays as used in the actual calculation!
   int id = get_global_id(0) ;   // id == ray index
   if (id>=NRAY_SPE) return ; // no more rays
   __global float *NTRUE   = &(NTRUE_ARRAY[id*CHANNELS]) ;
   __global float *SUM_TAU = &(SUM_TAU_ARRAY[id*CHANNELS]) ;
   int i ;
   for(int i=0; i<CHANNELS; i++) {
      NTRUE[i]   = 0.0f ;  SUM_TAU[i] = 0.0f ;
   }
   float tau, dtau, emissivity, doppler, nu, dx ;
   int row, shift ;
   constant float* profile ;
   float ip = IP[id] ; // impact parameter [GL] ;
   int INDEX=CELLS-1, dstep = -1 ;
   float colden=0.0f, coldenmol=0.0f, maxtau=0.0f ;
   while (1) {
      dx         =  STEP[id*CELLS+INDEX] ;          // [GL]
      colden    +=  dx*RHO[INDEX] ;                 // needs to be scaled later by GL
      coldenmol +=  dx*RHO[INDEX]*CLOUD[INDEX].z ;
      nu         =  NI[INDEX].x ;     
      tau        =  (fabs(NI[INDEX].y)<1.0e-26f) ? (1.0e-26f) :  (NI[INDEX].y) ;
      tau       *=  GN*GL*dx ;
      tau        =  clamp(tau, -2.0f, 1.0e10f) ;      
      // CLOUD[].y = effective radius,  CLOUD[].w = sigma, CLOUD[].x = Vrad
      doppler    =  dstep*CLOUD[INDEX].x * sqrt( max(0.0f, 1.0f-pow(ip/CLOUD[INDEX].y,2.0f)) ) ;
      // if (id==0) printf("doppler  %7.2f  --- tau %12.4e\n", doppler, tau) ;
      
      row        =  clamp((int)round(log(CLOUD[INDEX].w/SIGMA0)/log(SIGMAX)), 0, GNO-1) ;
      profile    =  &GAU[row*CHANNELS] ;
      shift      =  round(doppler/WIDTH) ;
      // emissivity =  H_PIx4 * freq * nu * Aul *dx  * I2T ;
      emissivity =  emis0 * nu * dx * GL ;      
      for(i=max(0, shift); i<min(CHANNELS, CHANNELS+shift); i++) {         
         dtau       =  tau*profile[i-shift] ;
         dx         =  emissivity*profile[i-shift]*GN*exp(-SUM_TAU[i]) ;
         dx        *=   (fabs(dtau)>1.0e-7f) ? ((1.0f-exp(-dtau)) / dtau) : (1.0f-0.5f*tau) ;
         NTRUE[i]   +=  dx ;
         SUM_TAU[i] +=  dtau  ;
      }
      // next cell
      INDEX += dstep ;
      if (INDEX>=CELLS) break ;
      if (INDEX<0) {             // we went through the centre cell, turn outwards
         INDEX = 1 ;  dstep = 1 ;
      } else {
         if (STEP[id*CELLS+INDEX]<=0.0f) { // ray does not go further in, turn outwards
            INDEX += 2 ; // we went through i but not i-1 => continue with i+1
            dstep  = 1 ;
         }
      }
      if (INDEX>=CELLS) break ;
   } // while(1)
   for (i=0; i<CHANNELS; i++) {
      NTRUE[i] -=  BG*(1.0f-exp(-SUM_TAU[i])) ;
      maxtau    =  max(maxtau, SUM_TAU[i]) ;
   }
   COLDEN[id].x  = colden ;
   COLDEN[id].y  = coldenmol ;
   COLDEN[id].z  = maxtau ;
}



#if 0
__kernel void ColumnDensity(
                            __global float4 *CLOUD,        //  0  [CELLS]: Vrad, Rc, dummy, sigma
                            __global float  *RHO,          //  1  [CELLS]
                            __global float  *IP,           //  2  impact parameter [GL]
                            __global float  *STEP,         //  3  STEP[iray*CELLS+iray]  [GL]
                            __global float  *COLDEN        //  4  NRAY_SPE
                           )
{
   // one work item per ray; the same rays as used in the actual calculation!
   int id = get_global_id(0) ;   // id == ray index
   if (id>=NRAY_SPE) return ; // no more rays
   int   i ;
   float dx, colden=0.0f ;
   float ip = IP[id] ; // impact parameter [GL] ;
   int   INDEX=CELLS-1, dstep = -1 ;
   while (1) {
      dx      =  STEP[id*CELLS+INDEX] ;  // [GL]
      colden +=  dx*RHO[INDEX] ;
      INDEX += dstep ;
      if (INDEX>=CELLS) break ;
      if (INDEX<0) {             // we went through the centre cell, turn outwards
         INDEX = 1 ;  dstep = 1 ;
      } else {
         if (STEP[id*CELLS+INDEX]<=0.0f) { // ray does not go further in, turn outwards
            INDEX += 2 ; // we went through i but not i-1 => continue with i+1
            dstep  = 1 ;
         }
      }
      if (INDEX>=CELLS) break ;
   } // while(1)
   COLDEN[id] = colden ;
}

#endif

